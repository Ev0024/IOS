# IOS-mini-project
calculator
this application is used to do simple calculations
